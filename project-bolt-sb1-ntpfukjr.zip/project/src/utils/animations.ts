export interface FadeInOptions {
  direction?: 'up' | 'down' | 'left' | 'right';
  duration?: number;
  delay?: number;
  threshold?: number;
  once?: boolean;
}

export const observeElements = (
  selector: string, 
  callback: (entry: IntersectionObserverEntry) => void,
  options: IntersectionObserverOptions = {}
) => {
  const { 
    root = null, 
    rootMargin = '0px', 
    threshold = 0.1,
    once = true 
  } = options;
  
  const elements = document.querySelectorAll(selector);
  
  if (elements.length === 0) return;
  
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          callback(entry);
          if (once) {
            observer.unobserve(entry.target);
          }
        }
      });
    },
    { root, rootMargin, threshold }
  );
  
  elements.forEach((element) => {
    observer.observe(element);
  });
  
  return observer;
};

interface IntersectionObserverOptions {
  root?: Element | null;
  rootMargin?: string;
  threshold?: number | number[];
  once?: boolean;
}