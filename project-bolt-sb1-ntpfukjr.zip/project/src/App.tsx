import React, { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Testimonials from './components/Testimonials';
import Pricing from './components/Pricing';
import ContactUs from './components/ContactUs';
import Footer from './components/Footer';
import AnimatedSection from './components/AnimatedSection';
import AboutUs from './components/AboutUs';
import PrivacyPolicy from './components/PrivacyPolicy';

function App() {
  const [currentPage, setCurrentPage] = React.useState<'home' | 'about' | 'privacy'>('home');

  useEffect(() => {
    document.title = 'NutriFy | Transforme sua forma de fazer dieta';

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const href = this.getAttribute('href');
        if (!href) return;
        
        const targetElement = document.querySelector(href);
        if (!targetElement) return;
        
        window.scrollTo({
          top: targetElement.getBoundingClientRect().top + window.scrollY - 80,
          behavior: 'smooth'
        });
      });
    });
  }, []);

  return (
    <div className="font-sans antialiased">
      <Header onPageChange={setCurrentPage} currentPage={currentPage} />
      
      {currentPage === 'home' ? (
        <main>
          <Hero />
          
          <AnimatedSection>
            <Features />
          </AnimatedSection>
          
          <AnimatedSection delay={0.2}>
            <Testimonials />
          </AnimatedSection>
          
          <AnimatedSection delay={0.3}>
            <Pricing />
          </AnimatedSection>

          <AnimatedSection delay={0.4}>
            <ContactUs />
          </AnimatedSection>
        </main>
      ) : currentPage === 'about' ? (
        <AboutUs />
      ) : (
        <PrivacyPolicy />
      )}
      
      <Footer onPageChange={setCurrentPage} />
    </div>
  );
}

export default App;