import React, { useState } from 'react';
import { Send } from 'lucide-react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      setEmail('');
    }
  };

  return (
    <section className="py-16 md:py-24 bg-black text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Fique Atualizado</h2>
          <p className="text-lg mb-8 text-gray-300">
            Inscreva-se em nossa newsletter para receber dicas, atualizações e ofertas especiais.
          </p>
          
          {isSubmitted ? (
            <div className="bg-white/10 rounded-lg p-6 backdrop-blur-sm">
              <div className="text-2xl font-bold mb-2">🎉 Obrigado por se inscrever!</div>
              <p>Em breve você receberá nossas novidades.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Digite seu email"
                  className="w-full px-4 py-3 rounded-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white"
                  required
                />
              </div>
              <button
                type="submit"
                className="bg-white text-black px-6 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors flex items-center justify-center"
              >
                Inscrever-se <Send className="ml-2 h-4 w-4" />
              </button>
            </form>
          )}
          
          <p className="mt-4 text-sm text-gray-400">
            Respeitamos sua privacidade. Cancele a qualquer momento.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;