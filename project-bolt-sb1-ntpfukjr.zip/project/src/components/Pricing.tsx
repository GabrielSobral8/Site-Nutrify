import React, { useState } from 'react';
import { Check } from 'lucide-react';

interface PricingPlanProps {
  title: string;
  price: string;
  description: string;
  features: string[];
  buttonText: string;
  link: string;
  isPopular?: boolean;
}

const PricingPlan: React.FC<PricingPlanProps> = ({
  title,
  price,
  description,
  features,
  buttonText,
  link,
  isPopular = false,
}) => {
  const [isClicked, setIsClicked] = useState(false);

  const handleClick = () => {
    setIsClicked(true);
    window.open(link, '_blank');
    setTimeout(() => setIsClicked(false), 500);
  };

  return (
    <div className={`
      bg-white rounded-xl overflow-hidden border transition-all
      ${isPopular ? 'border-[#8e2ad4] shadow-xl scale-105 lg:scale-110 z-10' : 'border-gray-200 shadow-sm hover:shadow-md'}
    `}>
      {isPopular && (
        <div className="bg-[#8e2ad4] text-white text-sm font-medium text-center py-1.5">
          Mais Popular
        </div>
      )}
      
      <div className="p-6 md:p-8">
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-gray-600 mb-6">{description}</p>
        
        <div className="mb-6">
          <span className="text-3xl md:text-4xl font-bold">{price}</span>
          <span className="text-gray-600 ml-2">/mês</span>
        </div>
        
        <ul className="space-y-4 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
        
        <button
          onClick={handleClick}
          className={`w-full py-3 rounded-lg font-medium transition-colors ${
            isClicked
              ? 'bg-[#8e2ad4] text-white'
              : isPopular
              ? 'bg-[#8e2ad4] text-white hover:bg-[#8e2ad4]/90'
              : 'bg-gray-100 text-gray-800 hover:bg-gray-200 hover:text-[#8e2ad4]'
          }`}
        >
          {buttonText}
        </button>
      </div>
    </div>
  );
};

const Pricing: React.FC = () => {
  const features = [
    "Fotos ilimitadas para registrar todas as suas refeições e acompanhar sua evolução",
    "Assistente 24 horas para tirar dúvidas e te manter no foco, a qualquer momento",
    "Lista de compras automática, baseada na sua dieta e preferências",
    "Lembretes inteligentes para não esquecer nenhuma refeição",
    "Diagnóstico personalizado com dicas e ajustes sob medida",
    "Importe sua dieta em PDF e tenha tudo organizado em segundos",
    "Alertas e notificações motivacionais para te manter engajado",
    "Dados 100% seguros e protegidos"
  ];

  const plans = [
    {
      title: 'Mensal',
      price: 'R$42,90',
      description: 'Ideal para começar sua jornada',
      features: features,
      buttonText: 'Começar Agora',
      link: 'https://hotm.art/A0aRpr'
    },
    {
      title: 'Trimestral',
      price: 'R$32,90',
      description: 'Perfeito para resultados consistentes',
      features: features,
      buttonText: 'Começar Agora',
      link: 'https://hotm.art/iXEiSu',
      isPopular: true,
    },
    {
      title: 'Anual',
      price: 'R$19,90',
      description: 'Melhor custo-benefício',
      features: features,
      buttonText: 'Começar Agora',
      link: 'https://hotm.art/mOeo24v'
    },
  ];

  return (
    <section id="pricing" className="py-16 md:py-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Preços Simples e Transparentes</h2>
          <p className="text-lg text-gray-600">
            Escolha o plano que melhor atende às suas necessidades.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-0 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <div key={index} className={`${
              index === 1 ? 'md:-my-4' : ''
            }`}>
              <PricingPlan {...plan} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;