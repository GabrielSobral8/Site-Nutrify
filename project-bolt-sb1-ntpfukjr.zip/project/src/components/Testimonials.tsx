import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface TestimonialProps {
  quote: string;
  name: string;
  role: string;
  image: string;
}

const testimonials: TestimonialProps[] = [
  {
    quote: "O NutriFy transformou completamente minha forma de acompanhar minha dieta. A interface intuitiva e os recursos poderosos me ajudaram a alcançar meus objetivos.",
    name: "Bianca Trazzi",
    role: "Perdeu 15kg em 6 meses",
    image: "https://res.cloudinary.com/dwolclfrs/image/upload/v1745804264/438004dc-3526-4505-acce-f829b80694c2_dlfvg2.jpg"
  },
  {
    quote: "Depois de tentar vários aplicativos de dieta, o NutriFy se destaca como o mais fácil de usar. Consegui manter minha dieta sem complicações.",
    name: "Breno Poloni",
    role: "Ganhou 8kg de massa magra",
    image: "https://res.cloudinary.com/dwolclfrs/image/upload/v1745804276/breno_ilqfvu.jpg"
  },
  {
    quote: "Os lembretes e o acompanhamento pelo WhatsApp fizeram toda a diferença. Nunca foi tão fácil manter uma dieta e ver resultados reais.",
    name: "Arthur Saiter",
    role: "Mantém dieta há 1 ano",
    image: "https://res.cloudinary.com/dwolclfrs/image/upload/v1745804264/IMG_2981_ttwt9u.png"
  }
];

const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <section id="testimonials" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">O que Nossos Clientes Dizem</h2>
          <p className="text-lg text-gray-600">
            Veja como o NutriFy está ajudando pessoas reais a alcançarem seus objetivos.
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto">
          <div className="relative">
            <div className="overflow-hidden">
              <div 
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${currentIndex * 100}%)` }}
              >
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="w-full flex-shrink-0 px-4">
                    <div className="bg-white rounded-xl p-8 md:p-10 shadow-md">
                      <div className="flex flex-col md:flex-row gap-6 md:gap-10 items-center">
                        <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden flex-shrink-0">
                          <img 
                            src={testimonial.image} 
                            alt={testimonial.name} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 text-center md:text-left">
                          <blockquote className="text-lg md:text-xl text-gray-700 mb-6">
                            "{testimonial.quote}"
                          </blockquote>
                          <div>
                            <div className="font-bold text-gray-900 mb-1">{testimonial.name}</div>
                            <div className="text-gray-600">{testimonial.role}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex justify-center mt-8 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentIndex ? 'bg-[#8e2ad4]' : 'bg-gray-300'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            
            <button 
              onClick={prevTestimonial}
              className="absolute top-1/2 left-2 md:-left-12 transform -translate-y-1/2 bg-white p-2 rounded-full shadow-md text-gray-600 hover:text-[#8e2ad4] transition-colors focus:outline-none"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            
            <button 
              onClick={nextTestimonial}
              className="absolute top-1/2 right-2 md:-right-12 transform -translate-y-1/2 bg-white p-2 rounded-full shadow-md text-gray-600 hover:text-[#8e2ad4] transition-colors focus:outline-none"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;