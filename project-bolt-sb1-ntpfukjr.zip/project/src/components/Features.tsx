import React, { useState } from 'react';
import { Camera, MessageSquare, FileText, Bell, Plus } from 'lucide-react';

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  mockupContent: {
    type: 'video' | 'image';
    url: string;
  };
}

const FeatureCard: React.FC<FeatureProps> = ({ icon, title, description, mockupContent }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="relative bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-300 group cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="bg-[#8e2ad4]/10 text-[#8e2ad4] p-3 rounded-lg inline-block mb-4 group-hover:bg-[#8e2ad4] group-hover:text-white transition-colors">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
      <div className="mt-3 flex items-center text-sm text-[#8e2ad4]">
        <Plus className="h-4 w-4 mr-1" /> Ver demonstração
      </div>
      
      {/* Mockup overlay */}
      <div 
        className={`absolute top-0 left-0 w-full h-full bg-white rounded-xl transition-all duration-300 ${
          isHovered ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="relative w-full h-full flex items-center justify-center p-4">
          <div className="relative w-[200px] h-[400px]">
            {/* Phone frame */}
            <div className="absolute inset-0 bg-black rounded-[2rem] shadow-xl">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-5 bg-black rounded-b-2xl"></div>
            </div>
            {/* Screen content */}
            <div className="absolute inset-[3px] rounded-[1.85rem] overflow-hidden">
              {mockupContent.type === 'video' ? (
                <video 
                  src={mockupContent.url}
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : (
                <img 
                  src={mockupContent.url}
                  alt={title}
                  className="w-full h-full object-cover"
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Features: React.FC = () => {
  const features = [
    {
      icon: <Camera className="h-6 w-6" />,
      title: "Registre suas refeições com fotos",
      description: "Envie uma foto da sua refeição e todos seus nutrientes e calorias serão calculados rapidamente.",
      mockupContent: {
        type: 'video' as const,
        url: "https://res.cloudinary.com/dwolclfrs/video/upload/v1745521984/RPReplay_Final1745521213_uwuo8p.mov"
      }
    },
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Registre também com texto ou áudio",
      description: "Se você se esqueceu de tirar uma foto da sua refeição, não se preocupe, basta um texto ou áudio detalhando a refeição.",
      mockupContent: {
        type: 'video' as const,
        url: "https://res.cloudinary.com/dwolclfrs/video/upload/v1745521985/RPReplay_Final1745521345_lvqxbs.mov"
      }
    },
    {
      icon: <FileText className="h-6 w-6" />,
      title: "Lista de Compras",
      description: "Envie um documento, em formato PDF, da sua dieta, e você terá em suas mãos uma lista semanal completa das suas refeições.",
      mockupContent: {
        type: 'video' as const,
        url: "https://res.cloudinary.com/dwolclfrs/video/upload/v1745521982/RPReplay_Final1745521431_jadxp1.mp4"
      }
    },
    {
      icon: <Bell className="h-6 w-6" />,
      title: "Lembretes",
      description: "Caso se esqueça de registrar suas refeições os Lembretes vão te ajudar a enviar todas refeições durante seu dia.",
      mockupContent: {
        type: 'video' as const,
        url: "https://res.cloudinary.com/dwolclfrs/video/upload/v1745521976/RPReplay_Final1745521130_bllcpv.mov"
      }
    }
  ];

  return (
    <section id="features" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Funções Projetadas para Seu Sucesso</h2>
          <p className="text-lg text-gray-600">
            Nossa plataforma combina recursos poderosos com uma interface intuitiva para ajudar você a alcançar seus objetivos nutricionais.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              mockupContent={feature.mockupContent}
            />
          ))}
        </div>
        
        <div className="mt-20">
          <div className="bg-white rounded-xl overflow-hidden shadow-lg">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 md:p-12 lg:order-2">
                <div className="max-w-lg">
                  <h3 className="text-2xl md:text-3xl font-bold mb-6">Acompanhamento nutricional simplificado</h3>
                  <p className="text-gray-600 mb-8">
                    Nossa interface intuitiva torna o acompanhamento nutricional mais fácil do que nunca. Registre suas refeições, acompanhe seu progresso e veja resultados em tempo real.
                  </p>
                  <ul className="space-y-4">
                    {[
                      "Interface intuitiva para registro de refeições",
                      "Visualização em tempo real do progresso",
                      "Biblioteca extensa de alimentos",
                      "Planos personalizáveis para cada objetivo"
                    ].map((item, index) => (
                      <li key={index} className="flex items-start">
                        <div className="bg-green-100 text-green-600 p-1 rounded-full mr-3 mt-1">
                          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="lg:order-1 relative min-h-[300px] lg:min-h-[500px]">
                <img
                  src="https://res.cloudinary.com/dwolclfrs/image/upload/v1745523720/ChatGPT_Image_24_de_abr._de_2025_16_41_48_lsm66j.png"
                  alt="Pessoas felizes com seus resultados"
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;