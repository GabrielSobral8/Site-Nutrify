import React from 'react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="pt-24 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Política de Privacidade da NutriFy</h1>
          
          <div className="prose prose-lg">
            <p className="text-lg text-gray-600 mb-6">
              A NutriFy se compromete a proteger a privacidade de seus usuários e a tratar as informações pessoais de acordo com a Lei Geral de Proteção de Dados (LGPD). Esta Política de Privacidade descreve como coletamos, usamos, armazenamos e protegemos suas informações pessoais quando você utiliza nossos serviços. Ao acessar e usar nossa plataforma, você concorda com os termos desta política.
            </p>
            
            <h2 className="text-2xl font-bold mt-8 mb-4">1. Coleta de Informações</h2>
            <p className="text-lg text-gray-600 mb-6">
              Coletamos informações pessoais para fornecer nossos serviços de nutrição baseados em inteligência artificial, como:
            </p>
            <ul className="list-disc pl-6 mb-6 text-lg text-gray-600">
              <li className="mb-2">Dados fornecidos diretamente por você, como nome, endereço de e-mail, informações de saúde e hábitos alimentares.</li>
              <li>Informações sobre o uso da plataforma, como interações com o aplicativo e dados de navegação.</li>
            </ul>

            <h2 className="text-2xl font-bold mt-8 mb-4">2. Uso das Informações</h2>
            <p className="text-lg text-gray-600 mb-4">As informações que coletamos são utilizadas para:</p>
            <ul className="list-disc pl-6 mb-6 text-lg text-gray-600">
              <li className="mb-2">Personalizar os serviços e recomendações de nutrição com base nas suas necessidades.</li>
              <li className="mb-2">Melhorar a experiência do usuário e a funcionalidade da plataforma.</li>
              <li>Enviar comunicações relacionadas aos nossos serviços, como atualizações, promoções e novidades.</li>
            </ul>

            <h2 className="text-2xl font-bold mt-8 mb-4">3. Compartilhamento de Informações</h2>
            <p className="text-lg text-gray-600 mb-6">
              Não compartilhamos suas informações pessoais com terceiros, exceto quando necessário para cumprir com obrigações legais, proteger nossos direitos ou com prestadores de serviços que auxiliam na operação da plataforma, sob termos que garantem a segurança de suas informações.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">4. Segurança das Informações</h2>
            <p className="text-lg text-gray-600 mb-6">
              Utilizamos medidas de segurança adequadas para proteger suas informações pessoais contra acesso não autorizado, alteração, divulgação ou destruição. No entanto, nenhuma transmissão de dados pela internet é totalmente segura, e não podemos garantir a segurança absoluta.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">5. Retenção de Dados</h2>
            <p className="text-lg text-gray-600 mb-6">
              Armazenamos suas informações pessoais pelo tempo necessário para fornecer nossos serviços e cumprir com as obrigações legais, conforme estabelecido pela LGPD. Quando os dados não forem mais necessários, serão excluídos de forma segura.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">6. Seus Direitos</h2>
            <p className="text-lg text-gray-600 mb-6">
              Em conformidade com a LGPD, você tem o direito de acessar, corrigir, atualizar ou excluir suas informações pessoais a qualquer momento. Para isso, basta entrar em contato conosco através dos canais de atendimento disponíveis.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">7. Alterações na Política de Privacidade</h2>
            <p className="text-lg text-gray-600 mb-6">
              Podemos atualizar esta Política de Privacidade periodicamente. Qualquer alteração será publicada nesta página, e a data de vigência será atualizada. Recomendamos que você revise nossa política regularmente.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">8. Contato</h2>
            <p className="text-lg text-gray-600 mb-6">
              Se você tiver dúvidas sobre nossa Política de Privacidade ou sobre como tratamos suas informações, entre em contato conosco através do e-mail nutrify.atendimento@gmail.com ou pelo nosso suporte.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;