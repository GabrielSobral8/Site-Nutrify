import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center">
      <img 
        src="https://res.cloudinary.com/dwolclfrs/image/upload/v1745520778/Logo_Uva_dgvhix.png" 
        alt="NutriFy Logo" 
        className="h-8 w-8 rounded-lg"
      />
      <span className="ml-2 text-xl font-bold text-black">
        NutriFy
      </span>
    </div>
  );
};

export default Logo;