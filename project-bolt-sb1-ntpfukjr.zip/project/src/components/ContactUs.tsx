import React from 'react';
import { Mail } from 'lucide-react';

const ContactUs: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Fale Conosco</h2>
          <p className="text-lg text-gray-600 mb-8">
            Nossa equipe está pronta para ajudar você a alcançar seus objetivos nutricionais.
          </p>
          <a
            href="mailto:nutrify.atendimento@gmail.com"
            className="inline-flex items-center bg-[#8e2ad4] text-white px-8 py-3 rounded-full font-medium hover:bg-[#8e2ad4]/90 transition-colors"
          >
            <Mail className="mr-2 h-5 w-5" />
            Enviar Email
          </a>
        </div>
      </div>
    </section>
  );
};

export default ContactUs;