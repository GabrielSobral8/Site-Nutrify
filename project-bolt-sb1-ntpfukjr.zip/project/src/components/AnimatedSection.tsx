import React, { useEffect, useRef } from 'react';
import { observeElements } from '../utils/animations';

interface AnimatedSectionProps {
  children: React.ReactNode;
  className?: string;
  direction?: 'up' | 'down' | 'left' | 'right';
  delay?: number;
  duration?: number;
  threshold?: number;
  once?: boolean;
}

const AnimatedSection: React.FC<AnimatedSectionProps> = ({
  children,
  className = '',
  direction = 'up',
  delay = 0,
  duration = 0.6,
  threshold = 0.1,
  once = true,
}) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    
    // Add initial hidden state
    section.style.opacity = '0';
    section.style.transform = getInitialTransform(direction);
    section.style.transition = `opacity ${duration}s ease-out, transform ${duration}s ease-out`;
    section.style.transitionDelay = `${delay}s`;
    
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            section.style.opacity = '1';
            section.style.transform = 'translate3d(0, 0, 0)';
            if (once) {
              observer.unobserve(entry.target);
            }
          } else if (!once) {
            section.style.opacity = '0';
            section.style.transform = getInitialTransform(direction);
          }
        });
      },
      { threshold }
    );
    
    observer.observe(section);
    
    return () => {
      observer.disconnect();
    };
  }, [direction, delay, duration, threshold, once]);
  
  return (
    <div ref={sectionRef} className={className}>
      {children}
    </div>
  );
};

const getInitialTransform = (direction: 'up' | 'down' | 'left' | 'right'): string => {
  switch (direction) {
    case 'up':
      return 'translate3d(0, 40px, 0)';
    case 'down':
      return 'translate3d(0, -40px, 0)';
    case 'left':
      return 'translate3d(40px, 0, 0)';
    case 'right':
      return 'translate3d(-40px, 0, 0)';
    default:
      return 'translate3d(0, 0, 0)';
  }
};

export default AnimatedSection;