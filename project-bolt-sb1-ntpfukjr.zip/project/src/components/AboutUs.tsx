import React from 'react';

const AboutUs: React.FC = () => {
  return (
    <div className="pt-24 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Sobre a NutriFy</h1>
          
          <div className="prose prose-lg">
            <p className="text-lg text-gray-600 mb-6">
              A NutriFy é uma empresa que usa inteligência artificial para resolver problemas relacionados à nutrição. Nosso objetivo é melhorar a forma como as pessoas e os profissionais de nutrição gerenciam a alimentação, oferecendo soluções práticas e personalizadas.
            </p>
            
            <p className="text-lg text-gray-600 mb-6">
              Por meio da nossa plataforma, é possível controlar dietas, acompanhar calorias e ajustar hábitos alimentares, tudo com o apoio da IA. A NutriFy busca tornar o processo de nutrição mais eficiente e acessível, atendendo às necessidades de cada pessoa.
            </p>
            
            <p className="text-lg text-gray-600">
              Nossa missão é ajudar tanto os clientes a melhorarem sua alimentação quanto os nutricionistas a oferecerem um atendimento mais preciso, utilizando tecnologia para tornar a nutrição mais simples e eficaz.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;