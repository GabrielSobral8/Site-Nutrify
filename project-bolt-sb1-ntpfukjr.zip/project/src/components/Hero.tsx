import React from 'react';
import { ChevronRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="pt-24 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col items-center text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 max-w-4xl mx-auto text-black">
            NutriFy
          </h1>
          
          <p className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
            Transforme sua forma de fazer dieta com a ajuda da I.A e com a facilidade do Whatsapp
          </p>
          
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4">
            <a 
              href="#pricing" 
              className="bg-[#8e2ad4] text-white px-8 py-3 rounded-full font-medium hover:bg-[#8e2ad4]/90 transition-colors w-full md:w-auto text-center"
            >
              Começar Agora
            </a>
            <a 
              href="#features" 
              className="flex items-center justify-center text-[#8e2ad4] font-medium hover:text-[#8e2ad4]/80 transition-colors w-full md:w-auto"
            >
              Ver Funções <ChevronRight className="ml-1 h-4 w-4" />
            </a>
          </div>
          
          <div className="mt-16 max-w-md mx-auto w-full">
            <div className="relative mx-auto w-[280px] h-[570px] rounded-[3rem] border-[14px] border-black shadow-xl bg-black overflow-hidden">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-[32px] bg-black rounded-b-3xl"></div>
              <div className="relative w-full h-full overflow-hidden rounded-[2.3rem] group">
                <img 
                  src="https://res.cloudinary.com/dwolclfrs/image/upload/v1745613183/IMG_2977_acmfo4.png" 
                  alt="iPhone mockup showing NutriFy app" 
                  className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;