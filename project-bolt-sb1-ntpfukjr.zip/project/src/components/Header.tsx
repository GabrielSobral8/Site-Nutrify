import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';

interface HeaderProps {
  onPageChange: (page: 'home' | 'about' | 'privacy') => void;
  currentPage: 'home' | 'about' | 'privacy';
}

const Header: React.FC<HeaderProps> = ({ onPageChange, currentPage }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const toggleMenu = () => setIsOpen(!isOpen);

  const handleNavClick = (page: 'home' | 'about' | 'privacy') => {
    onPageChange(page);
    setIsOpen(false);
  };

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          <div className="cursor-pointer" onClick={() => handleNavClick('home')}>
            <Logo />
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <nav className="flex items-center space-x-6">
              {currentPage === 'home' ? (
                <>
                  <a href="#features" className="text-gray-700 hover:text-[#8e2ad4] font-medium transition-colors">Funções</a>
                  <a href="#testimonials" className="text-gray-700 hover:text-[#8e2ad4] font-medium transition-colors">Depoimentos</a>
                  <a href="#pricing" className="text-gray-700 hover:text-[#8e2ad4] font-medium transition-colors">Preços</a>
                </>
              ) : null}
              <button 
                onClick={() => handleNavClick(currentPage === 'home' ? 'about' : 'home')}
                className="text-gray-700 hover:text-[#8e2ad4] font-medium transition-colors"
              >
                {currentPage === 'home' ? 'Sobre Nós' : 'Início'}
              </button>
            </nav>
          </div>
          
          <button className="md:hidden text-gray-700" onClick={toggleMenu}>
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div 
        className={`md:hidden absolute top-full left-0 right-0 bg-white shadow-md transition-all duration-300 ease-in-out ${
          isOpen ? 'max-h-screen opacity-100 visible' : 'max-h-0 opacity-0 invisible'
        } overflow-hidden`}
      >
        <nav className="container mx-auto px-4 py-4">
          <div className="flex flex-col space-y-4">
            {currentPage === 'home' ? (
              <>
                <a href="#features" className="text-gray-700 font-medium py-2">Funções</a>
                <a href="#testimonials" className="text-gray-700 font-medium py-2">Depoimentos</a>
                <a href="#pricing" className="text-gray-700 font-medium py-2">Preços</a>
              </>
            ) : null}
            <button 
              onClick={() => handleNavClick(currentPage === 'home' ? 'about' : 'home')}
              className="text-gray-700 font-medium py-2 text-left"
            >
              {currentPage === 'home' ? 'Sobre Nós' : 'Início'}
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header